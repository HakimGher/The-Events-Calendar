<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="./event.css">
    <script src="./eventScript.js" defer></script>

</head>
<body>

    
    <div  class="popup">
        <div class="popcont">
            <span class="close">&times;</span>
            <ul id='event-list'>
                <li>
          <input type="number" onchange="call()" id="fock" value="7" />
                </li>
                <li>
                    <div class="event">
                        <p>passage en revue des champs <span class="username" style="font-weight:bold; text-transform: capitalize; margin-left: 2px;">du 20 au 21 decembre</span></p>   
                                             <button class="del">SUPPRIMER</button>
                        <button class="mod">MODIFIER</button>
                        
                    </div>
    
                </li>
                <li>
                    <div class="event">
                        <p>passage en revue des champs <span class="username" style="font-weight:bold; text-transform: capitalize; margin-left: 2px;">du 20 au 21 decembre</span></p>   
                                             <button class="del">SUPPRIMER</button>
                        <button class="mod">MODIFIER</button>
                        
                    </div>    
                </li>
                <li>
                    <div class="event">
                        <p>passage en revue des champs <span class="username" style="font-weight:bold; text-transform: capitalize; margin-left: 2px;">du 20 au 21 decembre</span></p>   
                                             <button class="del">SUPPRIMER</button>
                        <button class="mod">MODIFIER</button>
                        
                    </div>    
                </li>
                <li>
                    <div class="event">
                        <p>passage en revue des champs <span class="username" style="font-weight:bold; text-transform: capitalize; margin-left: 2px;">du 20 au 21 decembre</span></p>   
                                             <button class="del">SUPPRIMER</button>
                        <button class="mod">MODIFIER</button>
                        
                    </div>    
                </li>
                <li>
                    <div class="event">
                        <p>passage en revue des champs <span class="username" style="font-weight:bold; text-transform: capitalize; margin-left: 2px;">du 20 au 21 decembre</span></p>   
                                             <button class="del">SUPPRIMER</button>
                        <button class="mod">MODIFIER</button>
                        
                    </div>    
                </li>
                <li>
                    <div class="event">
                        <p>passage en revue des champs <span class="username" style="font-weight:bold; text-transform: capitalize; margin-left: 2px;">du 20 au 21 decembre</span></p>   
                                             <button class="del">SUPPRIMER</button>
                        <button class="mod">MODIFIER</button>
                        
                    </div>    
                </li>
                <li>
                    <div class="event">
                        <p>passage en revue des champs <span class="username" style="font-weight:bold; text-transform: capitalize; margin-left: 2px;">du 20 au 21 decembre</span></p>   
                                             <button class="del">SUPPRIMER</button>
                        <button class="mod">MODIFIER</button>
                        
                    </div>    
                </li>
                <li>
                    <div class="event">
                        <p>passage en revue des champs <span class="username" style="font-weight:bold; text-transform: capitalize; margin-left: 2px;">du 20 au 21 decembre</span></p>   
                                             <button class="del">SUPPRIMER</button>
                        <button class="mod">MODIFIER</button>
                        
                    </div>    
                </li>
                <li>
                    <div class="event">
                        <p>passage en revue des champs passagel ajfgjalfd kkaljg; ajdflk gjkfdj gsfkjj ds;klg js;kl djfg dsf;kg sljg fs;j en revue des champs passage en revue des champs passage en revue des champs passage en revue des champs <span class="username" style="font-weight:bold; text-transform: capitalize; margin-left: 2px;">du 20 au 21 decembre</span></p>   
                                             <button class="del">SUPPRIMER</button>
                        <button class="mod">MODIFIER</button>
                        
                    </div>    
                </li>
                <li>
                    <div class="event">
                        <p>passage en revue des champs <span class="username" style="font-weight:bold; text-transform: capitalize; margin-left: 2px;">du 20 au 21 decembre</span></p>   
                                             <button class="del">SUPPRIMER</button>
                        <button class="mod">MODIFIER</button>
                        
                    </div>    
                </li>
                <li>
                    <div class="event">
                        <p>passage en revue des champs <span class="username" style="font-weight:bold; text-transform: capitalize; margin-left: 2px;">du 20 au 21 decembre</span></p>   
                                             <button class="del">SUPPRIMER</button>
                        <button class="mod">MODIFIER</button>
                        
                    </div>    
                </li>
                <li>
                    <div class="event">
                        <p>passage en revue des champs <span class="username" style="font-weight:bold; text-transform: capitalize; margin-left: 2px;">du 20 au 21 decembre</span></p>   
                                             <button class="del">SUPPRIMER</button>
                        <button class="mod">MODIFIER</button>
                        
                    </div>    
                </li>
            </ul>
        </div>
        </div>
</body>
</html>