<li value="1">hello</li>
<button id="get" onclick="call()" value="1">click</button>
<script type="text/javascript">



	function call(){
	let a = document.getElementById('get').id;
	alert(a);


	}
</script>